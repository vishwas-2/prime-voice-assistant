"""
Setup script for PRIME Voice Assistant.
"""

from setuptools import setup, find_packages
from pathlib import Path

# Read the README file
readme_file = Path(__file__).parent / "README.md"
long_description = ""
if readme_file.exists():
    long_description = readme_file.read_text(encoding="utf-8")

setup(
    name="prime-voice-assistant",
    version="0.1.0",
    author="PRIME Development Team",
    description="Proactive Reasoning Intelligent Machine Entity - A voice-activated AI assistant for CLI/terminal environments",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/prime-voice-assistant",
    packages=find_packages(exclude=["tests", "tests.*"]),
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Application Frameworks",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.9",
    install_requires=[
        "python-dotenv>=1.0.0",
        "SpeechRecognition>=3.10.0",
        "pyttsx3>=2.90",
        "pyaudio>=0.2.14",
        "spacy>=3.7.2",
        "nltk>=3.8.1",
        "psutil>=5.9.6",
        "pyautogui>=0.9.54",
        "Pillow>=10.1.0",
        "pytesseract>=0.3.10",
        "keyboard>=0.13.5",
        "mouse>=0.7.1",
        "cryptography>=41.0.7",
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.3",
            "pytest-cov>=4.1.0",
            "hypothesis>=6.92.1",
            "black>=23.12.1",
            "flake8>=6.1.0",
            "mypy>=1.7.1",
        ],
    },
    entry_points={
        "console_scripts": [
            "prime=prime.cli.main:main",
        ],
    },
)
