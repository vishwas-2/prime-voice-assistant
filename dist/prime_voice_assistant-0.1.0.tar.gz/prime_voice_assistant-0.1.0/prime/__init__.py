"""
PRIME Voice Assistant
Proactive Reasoning Intelligent Machine Entity

A voice-activated AI assistant designed for CLI/terminal environments.
"""

__version__ = "0.1.0"
__author__ = "PRIME Development Team"
